# Landingi-Recruitment-Task
Recruitment task for [Landingi](https://landingi.com/).

## Technologies
* REACT
* ES6
* Axios
* CSS Module
* Webpack

## Demo
https://jaroslaw91.github.io/Landingi-Recruitment-Task/

## Install
* clone this repository
* install packages in the main directory: `npm install`
* run App: `npm start`